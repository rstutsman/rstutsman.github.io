<?php

function substitute_stuff($source_sentences, $lang, $subst_array) {
  $tailsHashmap = array();
  $substs = $subst_array[$lang];

  if (count($source_sentences) == 0)
	die("Assertion failed: no source sentences for substitute_stuff");

  $togo = count($source_sentences);
  $coll = 0;
  foreach ($source_sentences as $pos=>$wordlist) {
	if ( ($pos % 25) == 0)
	  decho("Processing $pos/$togo sentences.");	
    $words = $wordlist->split();
	$prob = $wordlist->prob;
    
    $gen0 = array();
    $gen0[] = new WordList("", $prob, NULL);
    foreach ($words as $idx => $word) {
      $gen1 = array();
      foreach ($gen0 as $head) {
		$headpro = $head->prob;
		if (! isset($substs[$word])) {
			if ($idx == 0) {
			  $word = substr_replace($word,
										strtoupper(substr($word, 0, 1)),
										0, 1);
			}
			$gen1[] = buildWordList($word, $headpro, $head);
		} else {
		  $sub = $substs[$word];
		  foreach ($sub as $ss=>$sspro) {
			  if ($idx == 0) {
				$ss = substr_replace($ss, 
										  strtoupper(substr($ss, 0, 1)),
										  0, 1);
			  }
			  $gen1[] = buildWordList($ss, $headpro * $sspro, $head);
		  }
		}
      }
      $gen0 = $gen1;
    } 
  
	// reconcile gen0 with tails
	foreach ($gen0 as $wordlist) {
	  if (isset($tailsHashmap[$wordlist->hash])) {
		$tails = $tailsHashmap[$wordlist->hash];
		$found = FALSE;
		foreach ($tails as $tail) {
		  if ($tail->equals($wordlist)) {
			$tail->prob += $wordlist->prob;
			$found = TRUE;
			break;
		  }
		}
		if ($found == FALSE) {
		  $tails[] = $wordlist;
		  $coll++;
		  $tailsHashmap[$wordlist->hash] = $tails;
		}
	  } else {
		$tailsHashmap[$wordlist->hash] = array(0=>$wordlist);
	  }
	}	
  }

  // convert tails to $result
  $result = array();
  foreach ($tailsHashmap as $tails) {
	foreach ($tails as $tail) 
	  $result[] = $tail;  
  }

  if (count($result) == 0)
	die("Assertion failed (no results after substitution)!");

  return $result;
}


?>
