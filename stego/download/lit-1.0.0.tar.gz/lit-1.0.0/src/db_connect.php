<?php

	require_once('DB.php');
	
	$db = false;

	$dsn = parse_ini_file("./config.ini");
	$dsn = $dsn['dsn'];
	$options = array(
    	'debug'       => 2,
	    'portability' => DB_PORTABILITY_ALL,
	);

	$db =& DB::connect($dsn, $options);
	if (PEAR::isError($db))
	    die($db->getMessage());
	$db->setFetchMode(DB_FETCHMODE_ASSOC);

?>
