<?php
/*
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

	include("bin.php");


	include("trans/google.class.php");
	include("trans/babelfish.class.php");
	include("trans/linguatec.class.php");

	require_once("WordList.php");
	
	include("dicts/leotranslate.php");
	include("huffman.php");
	include("rectification.php");
	require_once("wordsubstitution.php");
	require_once("substitution_data.php");
	
	### Top Level Stego Functions ###
		
function stego_hide($stg, $cover, $engines, $source, $target, $badness, $rectify, $witnesses, $rewrite_articles, $rewrite_prepositions) {
		$cover_bytes = strlen($cover);
		$total_sentences = 0;
	
		$stg = bin_for_string($stg);
		decho("Binary string to hide: $stg\n");
		$cover = cleanup($cover);
		$output = "";

		$pos = 0;	# index of current bit to encode
		$total_cap = 0;
		$cover_pos = 0; # A an index counter for next_sentence to track point
		while (($sentence = next_sentence($cover, $cover_pos)) != false) {
			if (strlen($sentence) < 1) continue;
			decho("Working on '$sentence':");
			$total_sentences++;

			$results = &stego_permute($sentence, $source, $target, $engines, $badness, $rectify, $witnesses, $rewrite_articles, $rewrite_prepositions);
			if (count($results) == 0)
			  die("Assertion failed (stego permute returned 0 results!)");

			if (count($results) > 1) {
				$bits = strlen($stg);
				$tree = huff_tree($results);
				$s = huff_encode($stg, $tree);

				$bits -= strlen($stg);
				if ($bits < 0) $bits += 8;
				decho("* $bits bits stored here; " . strlen($stg) . " left to hide\n\n");
				$total_cap += $bits;
			} else {
			  decho("No room for storage here; nothing hidden.");
			  $s = $results[0]->__toString();
			  decho("Padding with $s\n\n");
			}
			$output .= " " . $s;
		}
		printf("\nTotal bits hidden:\t%6.4d\n", $total_cap);
		$output_bytes = strlen($output);
		$output_bytes_gz = strlen(gzcompress($output, 9));
		$bitrate = $total_cap / ($output_bytes * 8);
		$bitrate_gz = $total_cap / ($output_bytes_gz * 8);
		$bitrate_sentence = $total_cap / $total_sentences;
		printf("Avg bits per sentence:\t%6.2f\n", $bitrate_sentence);
		printf("Output size:\t\t%6d bytes, Bitrate %12.8f\n", $output_bytes, $bitrate);
		printf("Compressed output size:\t%6d bytes, Bitrate %12.8f\n", $output_bytes_gz, $bitrate_gz);
		return $output;
	}

function stego_extract($cover, $input, $engines, $source, $target, $badness, $rectify, $witnesses, $rewrite_articles, $rewrite_prepositions) {
		$total_cap = 0;
		$total_sentences = 0;

		$cover = cleanup($cover);
		$input = cleanup($input);
		
		$pos = 0;	# index of current bit to decode
		$stg = "";

		$cover_bytes = strlen($cover);		
		$cover_pos = 0; # Index counter for next_sentence to track point
		$input_pos = 0; # Index counter for next_sentence to track point
		while (($sentence = next_sentence($cover, $cover_pos)) != false) {
			if (strlen($sentence) < 1) continue;
			decho("Working on '$sentence':");
			$total_sentences++;
			
			#decho("Looking for: " . substr($input, $input_pos, 60) . "...\n");
			$results = &stego_permute($sentence, $source, $target, $engines, $badness, $rectify, $witnesses, $rewrite_articles, $rewrite_prepositions);
			
			if (count($results) < 2) {
				$s = $results[0]->__toString();
				$input_pos = skip_whitespace($input, $input_pos);
				$input_pos += strlen($s);
				decho("No room for storage here; input cursor skipped to: " . substr($input, $input_pos, 30) . "...\n\n");
				continue;
			}

			$b = false;
			$input_pos = skip_whitespace($input, $input_pos);
			foreach ($results as $r) {
				$s = $r->__toString();
				$i_chunk = substr($input, $input_pos, strlen($s));
				if (starts_with($input, $s, $input_pos)) {
					$b = $s;
					$input_pos += strlen($s);
					break;
				}
			}

			if ($b === false) {
				echo "WARNING: No translation found matching input\n";
				echo "Halting processing.  Output likely truncated.\n";
				break;
			}

			$tree = huff_tree($results);
			$find = toWordList($b, 1);
			$b = huff_decode($find, $tree);
			$bits = strlen($b);
			# This code flushes out a trace of the decoding in case
			# strings aren't being found properly
			#if ($bits == 0) {
			#	huff_decode($find, $tree, true);
			#}
			decho("* $bits ($b) bits stored here\n\n");
			$total_cap += $bits;

			$stg .= "$b";
		}
		echo "Extracted bit string: $stg\n";
		$pos = 0;
		$ascii = "";
		while ($pos + 7 < strlen($stg)) {
			$chunk = substr($stg, $pos, 8);
			$ascii .= chr(base_convert($chunk, 2, 10));
			$pos += 8;
		}
		if ($pos < strlen($stg))
			echo "Remaining data not in 8 bit block, truncating output.\n";

		printf("\nTotal bits extracted:\t%6.4d\n", $total_cap);
		$input_bytes = strlen($input);
		$input_bytes_gz = strlen(gzcompress($input, 9));
		$bitrate = $total_cap / ($cover_bytes * 8);
		$bitrate_gz = $total_cap / ($input_bytes_gz * 8);
		$bitrate_sentence = $total_cap / $total_sentences;
		printf("Avg bits per sentence:\t%6.2f\n", $bitrate_sentence);
		printf("Input size:\t\t%6d bytes, Bitrate %12.8f\n", $input_bytes, $bitrate);
		printf("Compressed input size:\t%6d bytes, Bitrate %12.8f\n", $input_bytes_gz, $bitrate_gz);

		return $ascii;
	}
	
	### Supporting Functions for Stego ###
	
	# This function is used by both hide and extract.  It generates the
	# legal sentence permutations in a central location to ensure that
	# the hide and extract routines always get identical translations
	# for a given set of parameters.
	function &stego_permute($sentence, $source, $target, $engines, $badness, $rectify, $witnesses, $rewrite_articles, $rewrite_prepositions) {
		$results = array();

		$eng_count = count($engines);
		foreach ($engines as $e)
			aggregate($results, cleanup($e->translate($sentence, $source, $target)), 1.0 / $eng_count);

		$tmpRes = array();
		foreach ($results as $trans=>$prob) {
			$twl = toWordList($trans, $prob);
			$tmpRes[] = $twl;
		}
		$results = $tmpRes;

		if (count(split(" ", $sentence)) > 20)	# Skip chunks that might be too complicated
			return $results;

		if ($witnesses < 100) {		# We use 100 as a flag for off/infinity
			$ss_res = semsub_permute($sentence, $results, $source, $target, $witnesses);
			$results = substitute_stuff($results, $target, $ss_res);
			decho(count($results) . " after semantic substitution");
		}
		if ($rewrite_articles) {
			global $article_substs;
			$results = substitute_stuff($results, $target, $article_substs);
			decho(count($results) . " after rewriting articles");
		}
		if ($rewrite_prepositions) {
			global $preposition_substs;
			$results = substitute_stuff($results, $target, $preposition_substs);
			decho(count($results) . " after rewriting prepositions");
		}
		if ($rectify != "off") {
			global $plural_substs;
			$results = rectify_stuff($results, $target, $plural_substs, ($rectify == "correct"));
			decho(count($results) . " after rectification");
		}
		if (count($results) == 0)
			die("Assertion failed (no results after post-passes)!");

		usort($results, "wordlist_cmp");

		if (count($results) == 0)
			die("Assertion failed (no results after asort)!");

		$correction = 0;
		$sentence_words = count(split(" ", $sentence));
		foreach ($results as $idx=>$wordlist) {
			if ($wordlist->prob + $wordlist->prob / (1-$correction) * $correction < ($badness / $sentence_words)) {
				unset($results[$idx]);
				$correction += $wordlist->prob;
			} else {
				break;
			}
		}

		if (count($results) == 0)
		  die("Assertion failed (no results after killing low-probs)!");

		$totalProb = 0;
		foreach ($results as $wordlist) 
			$totalProb += $wordlist->prob;
		
		// assert 1 == $totalProb + $correction (minus floating point error)
		foreach ($results as $wordlist) 
			$wordlist->prob = $wordlist->prob + $correction * ($wordlist->prob / $totalProb);
		
		usort($results, "wordlist_rcmp");

		# Implement hard ceiling on permuations here if necessary
		# So we can still keep the best translations
		# $results = array_slice($results, 0, 65536);

		$c = count($results);
		decho("$c unique permutations above threshold.\n");
		if ($c < 10)
			foreach ($results as $wordlist) printf("  (%6.1f)  %s\n", $wordlist->prob, $wordlist->__toString());

		if (count($results) == 0)
			die("Assertion failed (no results after stego_permute)!");

		return $results;
	}

	function aggregate(&$results, $sentence, $weight) {
		if (!isset($sentence) || $sentence == NULL || $sentence == '')
			return;
		if (isset($results[$sentence])) {
			$results[$sentence] += $weight;
		} else {
			$results[$sentence] = $weight;
		}
	}

	# Simply trims, decodes escape, and strips any \n
	function cleanup($s) {
		$s = trim($s);
		$s = html_entity_decode($s);
		# Strip newline and linefeed
		$s = str_replace(array("\n"), " ", $s);
		$s = preg_replace("/ \s+/", " ", $s);
		return $s;
	}
	
	# A debugging echo routine, tries to force more immediate display
	function decho($s) {
		global $debug;
		echo "$s\n";
		ob_flush();
	}
	
	### Post pass semantic substitution permutation system follows ###
	
	# Given a cover sentence and a translation from some source
	# try to guess what translations they chose for a subset of words.
	# Upon finding a match find permute using other words in their place
	# from our word translation source.  Limit the results to translations
	# that stay within the user's witness threshold.
function semsub_permute($cover, $trans, $source, $target, &$witnesses) {
  $result = array();
  $totalSubstitutions = 0;
  $sourceSplit = split(" ", $cover);
  $targetSplit = array();
  foreach ($trans as $wordlist)
  	$targetSplit += $wordlist->split();
  array_unique($targetSplit);
  foreach ($targetSplit as $targetWord) {
	if (! isset($targetWord))
	  continue;
	$sourceWords = translate($targetWord, $target, $source);
	if (! is_array($sourceWords))
	  continue;
	$totWit = 0;
	$words = array();
	foreach ($sourceWords as $sourceWord) {
	  if (! in_array($sourceWord, $sourceSplit)) 
		continue;
	  $associations = associate($sourceWord, $targetWord, 
									$source, $target);
	  foreach ($associations as $association => $witnessCount) 
		if ($witnessCount > $witnesses)
		  $totWit += $witnessCount;	  
	  foreach ($associations as $association => $witnessCount) 
		if ($witnessCount > $witnesses) {
		  $words[$association] = $witnessCount / $totWit;
		  $totalSubstitutions++;
		}
	}
	$targetWit = $totWit + 1;
	$totWit += $targetWit;
	$words[$targetWord] = $targetWit / $totWit;
	$result[$targetWord] = $words;
  }
  if ($totalSubstitutions > 8) {
  	$witnesses++;
  	decho ("Too many substitutions (". $totalSubstitutions . "), incrementing witnesses to $witnesses");
	return semsub_permute($cover, $trans, $source, $target, $witnesses);
  } else {
	decho ("Found " . $totalSubstitutions . " substitutions");
	return array($target => $result);
  }
 }
	
	 # Find similar words for the $trans word.
	 # Note that if $trans is not a translation of
	 # $original an empty array will be returned.
	 # Otherwise the returned array contains at
	 # least $trans.
	function associate($original, $trans, 
						   $source_lang, $target_lang) {
		global $db;
		$result = array();

		# Cache me if you can!
		$query = "SELECT ASSOCIATION, SCORE FROM WITNESS WHERE SOURCE_LANG = ";
		$query .= "'" . $db->escapeSimple($source_lang);
		$query .= "' AND TARGET_LANG  = '" . $db->escapeSimple($target_lang);
		$query .= "' AND SOURCE = '" . $db->escapeSimple($original);
		$query .= "' AND TARGET = '" . $db->escapeSimple($trans) ."'";
		
		$res =& $db->query($query);
		if (PEAR::isError($res))
		    die("associate: " . $res->getMessage() . "\n>> $query\n");
		while ($res->fetchInto($row))
		    $result[$row['id']] = (float)$row['score'];
		$res->free();
		if (count($result) > 0) {
			return $result;
		}
		# End caching
		unset($result);
		$result = array();

		$transArr = translate($original, $source_lang, 
							  $target_lang);

	  	if (! in_array($trans, $transArr)) 
			return $result; // nothing found!

		// set of witness candiates
		$witnessArr = translate($trans, $source_lang, $target_lang);
		foreach($transArr as $candidate) {
			if ("$candidate" == "$trans") {
				continue; // skip this one
			}
			$orginArr = translate($candidate, $target_lang, $source_lang);
			$witnessCount = 1.0;
			foreach($orginArr as $witness) 
				if (in_array($witness, $witnessArr)) 
					$witnessCount++;
			$result[$candidate] = $witnessCount;
		}
		if (count($result) == 0) {
			$id = $db->nextId('WITNESS');
			$query = "INSERT INTO WITNESS (ID, SOURCE_LANG, TARGET_LANG, ";
			$query .= "SOURCE, TARGET, ASSOCIATION, SCORE) VALUES (";
			$query .= "$id, '$source_lang', '$target_lang', '";
			$query .= $db->escapeSimple($original) . "', '";
			$query .= $db->escapeSimple($trans) . "', '-%-', 0)";
			$res = $db->query($query);
			if (PEAR::isError($res))
			    die("associate: " . $res->getMessage() . "\n>> $query\n");
		} else {
		  foreach ($result as $k=>$v) {
			$k = $db->escapeSimple($k);
			$id = $db->nextId('WITNESS');
			if (PEAR::isError($id))
			    die($id->getMessage());
			$query = "INSERT INTO WITNESS (ID, SOURCE_LANG, TARGET_LANG, ";
			$query .= "SOURCE, TARGET, ASSOCIATION, SCORE) VALUES (";
			$query .= "$id, '$source_lang', '$target_lang', '";
			$query .= $db->escapeSimple($original) . "', '";
			$query .= $db->escapeSimple($trans) . "', '$k', $v)";
			$res = $db->query($query);
			if (PEAR::isError($res))
			    die("associate: " . $res->getMessage() . "\n>> $query\n");
		  }
		}
		# End storage

		return $result;
	}


	### Generic text wrangling routines below ###
	
	function next_sentence($s, &$pos) {
		if ($pos >= strlen($s) - 1) return false;
		$whitespace = array(" ", "", "\n");
		while (in_array(substr($s, $pos, 1), $whitespace)) $pos++;
		$tokens = array(".", ":", "?", "!", ",", ";");
		$start = $pos;
		while ($pos < strlen($s) && !in_array(substr($s, $pos, 1), $tokens)) $pos++;
		$pos++;		# Include the punctuation mark
		return trim(substr($s, $start, $pos - $start));
	}
	
	function starts_with($s, $lead, $start = 0) {
		$lead = trim($lead);
		$chunk = substr($s, $start, strlen($lead));
		$chunk = trim($chunk);
		return (trim($chunk) == $lead);
	}
	
	function skip_whitespace($s, $pos) {
		$whitespace = array(" ", "", "\n");
		while (in_array(substr($s, $pos, 1), $whitespace)) $pos++;
		return $pos;
	}

	
?>
