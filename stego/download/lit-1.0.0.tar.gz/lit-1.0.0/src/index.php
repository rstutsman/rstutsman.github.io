<?php
	
	$options = parse_ini_file("./config.ini", true);
	ini_set("max_execution_time", 0);
	ini_set("output_buffering", "Off");
	ini_set("implicit_flush", true);
// ini_set("memory_limit", "64M");
	$debug = true;

?>
<html>
	<head>
                <title>Translation-based Steganography</title>
		<link rel="stylesheet" type="text/css" href="<? echo $options['web']['root']?>/style.css">
	</head>
<?php
  include("javascript.inc");
?>
	<body>
<?php
  include("main.php");
?>
</body>
</html>