<?php

	require_once("db_connect.php");
  // script to get simple translations of an english
  // or german word from dict.leo.org


// first some globals to configure where on the webpage the translations are...
/**
 * How deeply nested is the table that contains the translations in the HTML?
 */
$tableDepth = 1;

$tableLevels = array(0=>2, 1=>3);

$trSkip = 3; // skip first few lines in table

/**
 * In the translation table, what is the number of the TD colum with the
 * english word?
 */
$checkTDDepth = 2;

/**
 * In the translation table, what is the number of the TD colum with the
 * translation?
 */
$transTDDepth = 4;

function get_translations($keyword,
			  $node, 
                          &$positions,
			  $tdepth = 0,
                          &$trans = NULL) {
  global $tableLevels;
  global $trSkip;
  global $tableDepth;
  global $transTDDepth;
  global $checkTDDepth;
  
  $trans = (is_array($trans)) ? $trans : array();  
  if ( (isset($node->id)) &&
       ($node->id == TIDY_TAG_TABLE) &&
       ($node->hasChildren()) ) {
	if (isset($positions[$tdepth]))
      $positions[$tdepth]++;
    else
      $positions[$tdepth] = 1;
    if ($positions[$tdepth] != $tableLevels[$tdepth]) {
      // echo "Skipping table at $tdepth:$positions[$tdepth]\n";
      return;
    }
    // echo "Scanning table at $tdepth:$positions[$tdepth]\n";
    $trIndex = 0;
    $positions[$tdepth+1] = 0;
    foreach($node->child as $cc) {
      if ($tdepth < $tableDepth) {
	// echo "Recursing deeper at depth $tdepth\n";
	get_translations($keyword, $cc, $positions, $tdepth + 1, $trans);
      } else {
	// echo "Scanning table at $trIndex/$trSkip: $cc\n";
	if ( ($cc->id == TIDY_TAG_TR) &&
	     ($cc->hasChildren()) ) {
          $trIndex++;
          if ($trIndex <= $trSkip) {
	    // echo "Skipping trLine $cc\n";
            continue;
	  }
	  $tdIndex = 0;
	  foreach($cc->child as $td) {
	    if ($td->id == TIDY_TAG_TD) {
	      $tdIndex++;

	      if ( ($tdIndex == $checkTDDepth) &&
		   ($td->hasChildren()) ) {
		$count = 0;
		foreach($td->child as $atag) {
		  if (is_object($atag) && isset($atag->id) 
              &&  ($atag->id == TIDY_TAG_A) &&
		       ($atag->hasChildren()) ) {
		    $count++;		    
		    foreach($atag->child as $txt) {
		      // echo "E-FOUND: $txt";
		      $word = $txt;
		    }
		  }
		}
		if ( ($count != 1)  ||
		     ($word != "<b>" . $keyword . "</b>\n") )
		  break;
	      }  

	      if ( ($tdIndex == $transTDDepth) &&
		   ($td->hasChildren()) ) {
		$count = 0;
		foreach($td->child as $atag) {
		  if ( is_object($atag) && isset($atag->id) 
               && ($atag->id == TIDY_TAG_A) &&
		       ($atag->hasChildren()) ) {
		    foreach($atag->child as $txt) {
		      $count++;
		      if ($txt->isText()) {
			// echo "D-FOUND $txt";
			$word = $txt;
		      }
		    }
		  }
		}
		if ($count == 1) {		  
		  $trans[] = rtrim($word); // strip whitespace
		}
	      }  
	    }
	  }
	}
      }    
    }
  } else {
    if ($node->hasChildren()) {    
      foreach($node->child as $c) {
	get_translations($keyword, $c, $positions, $tdepth, $trans);
      }    
    }  
  }
  return array_unique($trans);
}

function translate($word, $source_lang, $target_lang) {
  global $db;
  if (!$word || !$source_lang || !$target_lang) {
    echo "Bad parameters for translate ($word, $source_lang, $target_lang).\n";
	return false;
  }

  $query = "SELECT TARGET FROM MAP WHERE SOURCE='" . $db->escapeSimple($word);
  $query .= "' AND SOURCE_LANG = '$source_lang' AND TARGET_LANG='$target_lang'";

  $res =& $db->query($query);
  if (PEAR::isError($res))
	die("translate: " . $res->getMessage() . "\n>> $query\n");
  while ($res->fetchInto($row))
	$map[] = $row['target'];
  $res->free();

  if (count($map) > 0) {
    if ($map[0] == "_")
      return array();
    return $map;
  }
  
  $ht = tidy_parse_file("http://dict.leo.org/?search=" . urlencode($word)); 
  // My test files:
  // $ht = tidy_parse_file("http://ovmj.org/~grothoff/silly.html");
  // $ht = tidy_parse_file("http://ovmj.org/~grothoff/search.html");
  if (! $ht) {
    echo "tidy_parse_file failed!\n";
    die();
  }
  $ht->cleanRepair(); 
  $res = get_translations($word, $ht->html(), $map);
  if (!$res || ! $res[0]) {
	$res[] = '_';
  }
  $oword = $db->escapeSimple($word);
  foreach ($res as $trans) {
	$otrans = $db->escapeSimple($trans);
	$map_id = $db->nextId('MAP');
    $query = "INSERT INTO MAP (ID, PROB, SOURCE_LANG, TARGET_LANG, SOURCE, TARGET) VALUES ($map_id, 1, '$source_lang', '$target_lang', '$oword','$otrans')";
    $i_res = $db->query($query);
	if (PEAR::isError($i_res))
		die("translate: " . $i_res->getMessage() . "\n>> $query\n");
  }
  return $res;
}

/*
// main (for testing)
if ($argc != 2) {
  echo "Pass word as an argument!\n";
  die();
 }
$translations = translate($argv[1], array());
foreach($translations as $word) {
  echo "$word\n";
}
*/

?>
