<?php

	ini_set("html_errors", false);
	ini_set("max_execution_time", 0);
	ini_set("implicit_flush", true);
	ini_set("register_argc_argv", true);
	$debug = true;

	require_once("./db_connect.php");

	include("./trans/google.class.php");
	include("./trans/babelfish.class.php");
	include("./trans/linguatec.class.php");
	
	include("./dicts/leotranslate.php");
	
	### Top Level Stego Functions ###

	$argv = array("", "../WWW/covers/en/manifest-beg.txt", "en", "de");

	if (count($argv) < 4)
		die ("Usage: prime_cache <coverfile> <source_lang> <target_lang>\n");

	$cover = file_get_contents($argv[1]);
	
	$engines = array();
	foreach (array("GoogleEngine", "BabelFishEngine", "LinguatecEngine") as $k) {
		global $db;
		$e = new $k;
		$e->connection = $db;
		$engines[] = $e;
	}

	echo "Caching ${argv[1]} from ${argv[2]} to ${argv[3]}\n";

	prime($cover, $engines, $argv[2], $argv[3]);

	function prime($cover, $engines, $source, $target) {
		$cover_bytes = strlen($cover);
		$total_sentences = 0;
	
		$cover_pos = 0; # A an index counter for next_sentence to track point
		while (($sentence = next_sentence($cover, $cover_pos)) != false) {
			if (strlen($sentence) < 1) continue;
			$total_sentences++;
			#$start = microtime(true);
			# The permutation code in here is old enough
			# that is may not work anymore even for caching,
			# It is more important to prime the translation
			# cache anyway as the other cache should be somewhat
			# redundant depending on the text
			stego_permute($sentence, $source, $target, $engines);
			#$cached = ((microtime(true) - $start) < 1.0);
			printf("%.2f%%\n", $cover_pos / $cover_bytes * 100);
			#echo $cached ? " (Cached)\n" : "\n";
			ob_flush();
			#if (!$cached) sleep(10);
		}
	}

	# Simply trims, decodes escape, and strips any \n
	function cleanup($s) {
		$s = trim($s);
		$s = html_entity_decode($s);
		# Strip newline and linefeed
		$s = str_replace(array("\n"), " ", $s);
		return $s;
	}
	
	function stego_permute($sentence, $source, $target, $engines) {
        $results = array();
        foreach ($engines as $e)
            aggregate($results, cleanup($e->translate($sentence, $source, $target)), $e->probability);

		#foreach ($results as $k=>$v)
		#	semsub_permute($sentence, $k, $source, $target, 0);
	}

	function aggregate(&$results, $sentence, $weight) {
		if (!isset($sentence) || $sentence == NULL || $sentence == '')
			return;
		if (isset($results[$sentence])) {
			$results[$sentence] += $weight;
		} else {
			$results[$sentence] = $weight;
		}
	}
	
	# A debugging echo routine, tries to force more immediate display
	function decho($s) {
		global $debug;
		echo "$s\n";
		ob_flush();
	}
	
	### Post pass semantic substitution permutation system follows ###
	
	function semsub_permute($cover, $trans, $source, $target) {
		$cover_tokens = split(" ", $cover);
		foreach ($cover_tokens as $t) {
			$subs = find_translations($t, $source, $target);
			$trans_sub = "";
			foreach ($subs as $sub) {
				if (strstr($trans, $sub)) {  # Perfect, we've found the word
					$trans_sub = $sub;
					break;
				}
			}
			if ($trans_sub != "") {	# Since we found the word dig deeper
				associate($t, $trans_sub, 0, $source, $target);
			}
		}
	}
	
	function find_translations($a, $source, $target) {
		$subs = translate($a, $source, $target);
		return $subs;
	}
	
	function associate($original, $trans, $witnessThreshold, $source_lang, $target_lang) {
		$result = array();
		$transArr = translate($original, $source_lang, $target_lang);
		
	  	if (! in_array($trans, $transArr))
			return $result; // nothing found!
		aggregate($result, $trans, 1);

		// set of witness candiates
		$witnessArr = translate($trans, $source_lang, $target_lang);
		foreach($transArr as $candidate) {
			if ("$candidate" == "$trans") {
				continue; // skip this one
			}
			$orginArr = translate($candidate, $target_lang, $source_lang);
			$witnessCount = 0;
			foreach($orginArr as $witness) {
				if (in_array($witness, $witnessArr)) {
					$witnessCount++;
				}
				if ($witnessCount >= $witnessThreshold) {
					aggregate($result, $candidate, $witnessCount);
                }
			}
		}
		decho(count($result) . " unique associations.");
		return $result;
	}

	### Generic text wrangling routines below ###
	
	function next_sentence($s, &$pos) {
		if ($pos >= strlen($s) - 1) return false;
		$whitespace = array(" ", "", "\n");
		while (in_array(substr($s, $pos, 1), $whitespace)) $pos++;
		$tokens = array(".", ":", "?", "!", ",", ";");
		$start = $pos;
		while ($pos < strlen($s) && !in_array(substr($s, $pos, 1), $tokens)) $pos++;
		$pos++;		# Include the punctuation mark
		return trim(substr($s, $start, $pos - $start));
	}
	
	function starts_with($s, $lead, $start = 0) {
		$lead = trim($lead);
		$chunk = substr($s, $start, strlen($lead));
		$chunk = trim($chunk);
		return (trim($chunk) == $lead);
	}
	
	function skip_whitespace($s, $pos) {
		$whitespace = array(" ", "", "\n");
		while (in_array(substr($s, $pos, 1), $whitespace)) $pos++;
		return $pos;
	}

	
?>
