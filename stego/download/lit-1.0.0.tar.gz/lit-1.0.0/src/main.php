<?php 
        if ($debug) { ?><div class="debugMessage"><div class="debugMessageHeader">Debug Output</div><pre><? } 
	require_once("db_connect.php");
	require_once("transstego.php");
	
	$debug = true;
	
	$values = $_POST;
	if (!isset($values)) $values = $_GET;
	
	$errors = "";
	
	if (isset($values['cover_selection']) && $values['cover_selection'] != 'custom')
		$values['cover'] = file_get_contents("covers/" . $values['source_lang'] . "/" . $values['cover_selection'] . ".txt");

	if (isset($values['object_selection']) && $values['object_selection'] != 'custom')
		$values['object'] = file_get_contents("objects/" . $values['object_selection'] . ".txt");
	
	if (isset($values['submit'])) {
		$errors = validate_form($values);
		if ($errors == "") {
			$engines = array();
			foreach ($values as $k=>$v) {
				if (ereg("engine$", $k)) {
					$e = new $k;
					$e->connection = $db;
					$engines[] = $e;
				}
			}
			if ($values['mode'] == "encrypt") {
				$values['result'] = stego_hide($values['object'],
											   $values['cover'],
											   $engines,
											   $values['source_lang'],
											   $values['target_lang'],
							       $values['badness'],
								$values['rectify'],
											   $values['witnesses'],
								  isset($values['rewrite_articles']),
								  isset($values['rewrite_prepositions']));
			} else {
				$values['object'] = stego_extract($values['cover'],
												  $values['result'],
												  $engines,
												  $values['source_lang'],
												  $values['target_lang'],
								  $values['badness'],
								$values['rectify'],
												  $values['witnesses'],
								  isset($values['rewrite_articles']),
								  isset($values['rewrite_prepositions']));
			}
		}
	} else { # Default values
		$values['source_lang'] = 'de';
		$values['target_lang'] = 'en';
		$values['witnesses'] = 4;
		$values['mode'] = 'encrypt';
		$values['rectify'] = 'off';
		$values['googleengine'] = 'On';
		$values['linguatecengine'] = 'On';
		$values['badness'] = '0.05';

		$values['result'] = "";
		$values['object'] = "";
		$values['object_selection'] = "manifest-beg";
	}
	$db->disconnect();
	
	function validate_form($values) {
		$errors = "";
		if (!isset($values['mode'])) {
			$errors .= "Please select a mode of operation.\n";
		} else if ($values['mode'] == "encrypt") {
			if (!isset($values['cover']) || strlen(trim($values['cover'])) < 1)
				$errors .= "To hide information a cover text must be provided.\n";
			if (!isset($values['object']) || strlen(trim($values['object'])) < 1)
				$errors .= "To hide information a steganographic object must be provided.\n";
		} else if ($values['mode'] == "decrypt") {
			if (!isset($values['cover']) || strlen(trim($values['cover'])) < 1)
				$errors .= "To extract information a cover text must be provided.\n";
			if (!isset($values['result']) || strlen(trim($values['result'])) < 1)
				$errors .= "To extract information a resultant text must be provided.\n";
		}
		return $errors;
	}
?>
		<? if ($debug) { ?></pre></div><? } ?>
		<? if ($errors != "") { ?>
			<div class="errorMessage">
				<div class="errorMessageHeader">Error</div>
				<pre><?=$errors?></pre>
			</div>
		<? } ?>
		<form name="stego" method="post" ction="http://www-cgi.cs.purdue.edu/cgi-debug/rstutsma/testing/index.php">
			<table>
				<tr>
					<th>Cover</th>
					<td>
						<select name="cover_selection" id="cover_selection" onchange="updateCoverSource();">
							<option value="manifest-beg" <?=$values['cover_selection'] == "manifest-beg" ? "selected" : ""?>>Communist Manifesto - First Section</option>
							<option value="manifest" <?=$values['cover_selection'] == "manifest" ? "selected" : ""?>>Communist Manifesto</option>
							<option value="eu-turkei" <?=$values['cover_selection'] == "eu-turkei" ? "selected" : ""?>>Zeit.de -  Turkey/EU News</option>
							<option value="custom" <?=$values['cover_selection'] == "custom" ? "selected" : ""?>>Custom</option>
						</select><br/>
						<textarea name="cover" id="cover" rows="5" cols="50" disabled="yes"><?=$values['cover']?></textarea>
						<script>
							function updateCoverSource() {
								var t = document.getElementById('cover');
								var c = document.getElementById('cover_selection');
								t.disabled = (c.value != 'custom');
							}
							updateCoverSource();
						</script>
					</td>
				</tr>
				<tr>
					<th>Result</th>
					<td>
						<textarea name="result" rows="5" cols="50"><?=$values['result']?></textarea>
					</td>
				</tr>
				<tr>
					<th>Object</th>
					<td>
						<select name="object_selection" id="object_selection" onchange="updateObjectSource();">
							<option value="fight" <?=$values['object_selection'] == "fight" ? "selected" : ""?>>Purdue Fight Song</option>
							<option value="fight-gz" <?=$values['object_selection'] == "fight-gz" ? "selected" : ""?>>Purdue Fight Song - Compressed</option>
							<option value="custom" <?=$values['object_selection'] == "custom" ? "selected" : ""?>>Custom</option>
						</select><br/>
						<textarea name="object" id="object" rows="5" cols="50" disabled="yes"><?=$values['object']?></textarea>
						<script>
							function updateObjectSource() {
								var t = document.getElementById('object');
								var c = document.getElementById('object_selection');
								t.disabled = (c.value != 'custom');
							}
							updateObjectSource();
						</script>
					</td>
				</tr>
				<tr>
					<th>Mode</th>
					<td>
						<input type="radio" name="mode" value="encrypt" onclick="toggleOptionsDisplay();" <?=$values['mode'] == "encrypt" ? "checked=\"true\"" : ""?>/> Hide
						<input type="radio" name="mode" value="decrypt" onclick="toggleOptionsDisplay();" <?=$values['mode'] == "decrypt" ? "checked=\"true\"" : ""?>/> Extract
					</td>
				</tr>
				<tr>
					<th>Options</th>
					<td>
						<table>
							<tr>
								<th colspan="3">
									Translation
								</th>
							</tr>
							<tr>
								<td>Source Language</td>
								<td>
									<select name="source_lang">
										<option value="en" <?=$values['source_lang'] == "en" ? "selected" : ""?>>en</option>
										<option value="de" <?=$values['source_lang'] == "de" ? "selected" : ""?>>de</option>
										<option value="fr" <?=$values['source_lang'] == "fr" ? "selected" : ""?>>fr</option>
									</select>
								</td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Target Language</td>
								<td>
									<select name="target_lang">
										<?php if (!isset($values['target_lang'])) $values['target_lang'] = 'de'; ?>
										<option value="en" <?=$values['target_lang'] == "en" ? "selected" : ""?>>en</option>
										<option value="de" <?=$values['target_lang'] == "de" ? "selected" : ""?>>de</option>
										<option value="fr" <?=$values['target_lang'] == "fr" ? "selected" : ""?>>fr</option>
									</select>
								</td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Badness Threshold</td>
								<td>
									<input name="badness" value="<? echo $values['badness']; ?>"></input>
								</td>
								<td>
								</td>
							</tr>
									       
							<tr>
								<th colspan="3">
									Engines
								</th>
							</tr>
							<tr>
								<td>Google</td>
								<td><input name="googleengine" type="checkbox" <?=(isset($values['googleengine']) ? 'checked="true"' : '')?>/></td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Altavista BabelFish</td>
								<td><input name="babelfishengine" type="checkbox" <?=(isset($values['babelfishengine']) ? 'checked="true"' : '')?>/></td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Linguatec</td>
								<td><input name="linguatecengine" type="checkbox" <?=(isset($values['linguatecengine']) ? 'checked="true"' : '')?>/></td>
								<td>
								</td>
							</tr>
						</table>
						<br/>
						<table>
							<tr>
								<th colspan="3">
									Post-pass Semantic Substitution
								</th>
							</tr>
							<tr>
								<td>Witness Threshold</td>
								<td>
									<select name="witnesses">
										<option value="0" <?=$values['witnesses'] == "0" ? "selected" : ""?>>0</option>
										<option value="1" <?=$values['witnesses'] == "1" ? "selected" : ""?>>1</option>
										<option value="2" <?=$values['witnesses'] == "2" ? "selected" : ""?>>2</option>
										<option value="4" <?=$values['witnesses'] == "4" ? "selected" : ""?>>4</option>
										<option value="8" <?=$values['witnesses'] == "8" ? "selected" : ""?>>8</option>
										<option value="100" <?=$values['witnesses'] == "100" ? "selected" : ""?>>Infinite (Off)</option>
									</select>
								</td>
								<td class="info">
									The number of synonyms in the target language that must also be that must match synonyms in the source language.  A higher witness count generally increases coherrency while a lower count potentially increases the amount of information that can be hidden.
								</td>
							</tr>
							<tr>
								<td>Custom Rewrite: Articles</td>
								<td><input type="checkbox" name="rewrite_articles" <?=(isset($values['rewrite_articles']) ? 'checked="true"' : '')?>/></td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Custom Rewrite: Prepositions</td>
								<td><input type="checkbox" name="rewrite_prepositions" <?=(isset($values['rewrite_prepositions']) ? 'checked="true"' : '')?>/></td>
								<td>
								</td>
							</tr>
							<tr>
								<td>Selective Rectification</td>

								<td>

						<input type="radio" name="rectify" value="off" <?=$values['rectify'] == "off" ? "checked=\"true\"" : ""?>/> Off<br/>
						<input type="radio" name="rectify" value="hide" <?=$values['rectify'] == "hide" ? "checked=\"true\"" : ""?>/> Hide<br/>
						<input type="radio" name="rectify" value="correct" <?=$values['rectify'] == "correct" ? "checked=\"true\"" : ""?>/> Correct
								</td>
								<td class="info">
									Selectively repair known inaccuracies in the translation engines to hide additional information.<br/>Alternatively, always correct these problems at the cost of possible bitrate.
								</td>
							</tr>
						</table>
						<div id="hideOptions">
						</div>
						<div id="extractOptions">
							<!-- Extract specific options go here -->
						</div>
						<script>toggleOptionsDisplay();</script>
					</td>
				</tr>
				<tr>
					<td colspan="2" style="text-align: right;">
						<input type="submit" name="submit" value="Submit"/>
					</td>
				</tr>
			</table>
		</form>
