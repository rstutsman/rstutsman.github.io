<?php
$internTable = array();

class WordList {
  var $prob;
  var $head;
  var $word;
  var $hash;
  var $pos;
  function WordList($ww, $pr, $hh=NULL) {
	global $internTable;
	
	$ww = trim($ww);
	#if ($hh != NULL && strlen($hh->word) < 1 && strlen($ww) < 1) {
	#	print_r(debug_backtrace());
	#	die ("Tried to append a 0 length string to a WordList\n");
	#}
	$toks = explode(" ", $ww);
	if (($c = count($toks)) > 1) {
		$ww = $toks[$c - 1];
		unset($toks[$c - 1]); 
		$hh = new WordList(implode(" ", $toks), $pr, $hh);
	}
	if (! isset($internTable[$ww])) {
	  $internTable[$ww] = $ww;
	  $iw = $ww;
	} else
	  $iw = $internTable[$ww];
	$this->head = $hh;
    $this->prob = $pr;
	$this->word = $iw;
	if ($hh == NULL) {
	  $ph = 0;
	  $this->pos = 0;
	} else {
	  $ph = $hh->hash;
	  $this->pos = $hh->pos + 1;
	}
	$this->hash 
	  = (crc32($this->word) / (1 + $this->pos)) ^ ($ph + $this->pos);
	// 	echo "Computing hash of " . $this->__toString() . " to be " . $this->hash . "\n";
  }
  function equals($wl) {
	if ($wl->hash != $this->hash) {
		return false;
	} else if ($wl->word != $this->word) {
		return false;
	} else if ($wl->head === $this->head) {
		return true;
	} else if ( ($wl->head == NULL) || 
		 ($this->head == NULL) ) {
		return false;
	} else {
	  return $this->head->equals($wl->head);
	}
	return false;
  }
  function append($word, $pr) {
	if (strlen(trim($word)) < 1)
		return $pr;
    return new WordList($word, $pr, $this);
  }
  function split() {   
	if (isset($this->head)) {
	  $ar = $this->head->split();
	  $ar[] = $this->word;
	  return $ar;
	} else {
	  return array(0=>$this->word);
	}	 
  }
  
  function __toString() {
    if (isset($this->head)) {
	  if ($this->word == "")
		return $this->head->__toString();
	  else
		return $this->head->__toString() . " " . $this->word;
	} else
	  return $this->word;
  }
  function __clone() {
	if ($this->head != NULL)
	  $this->head = clone($this->head);
  }
}

function toWordList($str, $pr) {
  #$str = trim($str);
  $str = preg_replace("/ \s+/", " ", $str);
  $tokens = split(" ", $str);
  $ret = NULL;
  foreach($tokens as $word)
	$ret = new WordList($word, $pr, $ret);
  return $ret;
}

function debugCompare($l, $r) {
	if ($l == NULL && $r == NULL) return;
	if ($l)
		echo $l->hash . ": '" . $l->word . "'\t";
	else
		echo "NULL\t";
	if ($r)
		echo $r->hash . ": '" . $r->word . "'\n";
	else
		echo "NULL\n";
	debugCompare($l ? $l->head : NULL, $r ? $r->head : NULL);
}

function buildWordList($word, $prob, $head = NULL) {
	if ($head != NULL && $word == "") {
		$n = clone($head);
		$n->prob = $prob;
	} else {
		$n = new WordList($word, $prob, $head);
	}
	return $n;

}

#echo "<pre>";
#$w = toWordList("The large industry manufactured the world market, which the discovery America prepared.");
#echo "\n\n/" . $w->__toString() . "/";
#echo "</pre>";


?>
