<?php
/**
 * Either fix the sentence (foots => feet, always,
 * possibly reducing the bitrate) or
 * use the known errors to hide stuff (feet => foots),
 * possibly making it easier to detect stego.
 */
function rectify_stuff($source_sentences, 
					   $lang, 
					   $rect_array,
				   $improve_only) {
  $tailsHashmap = array();
  $substs = $rect_array[$lang];

  foreach ($source_sentences as $input) {
	$prob = $input->prob;
    $words = $input->split();
    
    $gen0 = array();
    $gen0[] = new WordList("", $prob, NULL);
    foreach ($words as $idx => $word) {
      $gen1 = array();
      foreach ($gen0 as $head) {
		$headpro = $head->prob;
		$sub = isset($substs[$word]) ? $substs[$word] : NULL;
		if (! $sub) {
		  $gen1[] = new WordList($word, $headpro, $head);
		} else {
		  if ($improve_only) {
			$gen1[] = new WordList($sub, $head, $headpro);
		  } else {
			$gen1[] = new WordList($sub, $head, $headpro * 0.95);
			$gen1[] = new WordList($word, $head, $headpro * 0.05);
		  }
		}
      }
      $gen0 = $gen1;
    }
    // reconcile gen0 with tails
    foreach ($gen0 as $wordlist) {
	  if (isset($tailsHashmap[$wordlist->hash])) {
		$tails = $tailsHashmap[$wordlist->hash];	  
		$found = FALSE;
		foreach ($tails as $tail) {
		  if ($tail->equals($wordlist)) {
			$tail->prob += $wordlist->prob;
			$found = TRUE;
			break;
		  }
		}
		if ($found == FALSE) {
		  $tails[] = $wordlist;
		  $tailsHashmap[$wordlist->hash] = $tails;
		}
	  } else {
		$tailsHashmap[$wordlist->hash] = array(0=>$wordlist);
	  }
	}

  }

  // convert tails to $result
  $result = array();
  foreach ($tailsHashmap as $tails) 
	foreach ($tails as $tail) 
	  $result[] = $tail;  

  if (count($result) == 0)
	die("Assertion failed (no results after substitution)!");
  return $result;
}

?>