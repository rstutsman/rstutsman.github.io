<?php
	require_once("google.class.php");
	require_once("degermanize.php");
	
	# What the URL looks like to get a translation from this engine
	# http://www.linguatec.net/etstext/ptwebtext?W=0&client=web&gui=e&textart=text&username=PTO&userid=00000011&nummer=0&enc=unicode&langpair=EG&SA=0&text=This%20is%20a%20test

	class LinguatecEngine extends GoogleEngine {

		var $action = "http://www.linguatec.net/etstext/ptwebtext";
		var $id = 130;
	
		function remove_garbage($node) {
			$text = $node->child[12]->child[0]->child[1]->child[10]->child[7]->child[0]->child[1]->child[0];
			# Sometimes their engine gives us the textbox object
			$text = str_replace("\n", " ", $text);
			$text = preg_replace('/\<\/?textarea.*?\>/', "", "" . $text);
			return $text;
		}

		function create_langpair($source, $dest) {
			$map = array(
				'en' => 'E',
				'de' => 'G',
				'fr' => 'F',
			);
			return $map[$source] . $map[$dest];
		}

		function build_url($text, $source, $dest) {
			$langpair = $this->create_langpair($source, $dest);
			$text = degermanize($text);

			$text = urlencode($text);
			$action = $this->action;
			$url = $this->action;
			$url = "$url?W=0&client=web&gui=e&textart=text&username=PTO&userid=00000011&nummer=0&enc=unicode&langpair=$langpair&SA=0&text=$text";
			return $url;
		}
		
	}
?>
