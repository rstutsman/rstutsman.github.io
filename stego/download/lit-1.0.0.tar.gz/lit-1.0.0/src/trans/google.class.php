<?php
	include("engine.class.php");
	# Google's engine uses a very simple format:
	# http://translate.google.com/translate_t?langpair=XX|XX&text=XXXXXX
	# where an example of langpair is en|de

	class GoogleEngine extends GenericWebEngine {

		var $action = "http://translate.google.com/translate_t";
		var $id = 128;
	
		function translate($text, $source, $dest) {
			$trans = parent::translate($text, $source, $dest);
			if ($trans != false) return $trans;
			$url = $this->build_url($text, $source, $dest);
			for ($tries = 0, $tidy = false; $tries < 5 && $tidy == false; $tries++) {
				if ($tries > 0)
					echo "Failed to fetch translation, retrying.\n";
				$tidy = @$this->get_url($url);
			}
			if ($tidy === false) die("Could not translate\n");
			$trans = $this->remove_garbage($tidy->body());
			if ($trans->child[0])
				$trans = $trans->child[0];
			$trans = str_replace("\n", " ", $trans);
			$this->add_cache($text, $trans, $source, $dest);
			return $trans;
		}
	
		function remove_garbage($node) {
			if (!isset($node->id)) return $node;
			if ($node->id == TIDY_TAG_TEXTAREA)
				return $node;
			else if ($node->hasChildren())
				foreach ($node->child as $c) {
					$node = $this->remove_garbage($c);
					if (is_object($node)
						&& isset($node->id)
						&& $node->id == TIDY_TAG_TEXTAREA)
						return $node;
				}
		}

		function create_langpair($source, $dest) {
			return urlencode("$source|$dest");
		}

		function build_url($text, $source, $dest) {
			$langpair = $this->create_langpair($source, $dest);
			$text = urlencode($text);
			$action = $this->action;
			$url = $this->action;
			return "$url?langpair=$langpair&text=$text";
		}
		
		function cleanup($s) {
			$s = trim($s);
			$s = html_entity_decode($s);
			# Strip newline and linefeed
			$s = str_replace(array("\014", "\010"), "", $s);
			return $s;
		}

	}
?>
