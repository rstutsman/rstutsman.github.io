<?php
	require_once("google.class.php");

	class BabelFishEngine extends GoogleEngine {

		var $action = "http://babelfish.altavista.com/tr";
		var $id = 129;

		function create_langpair($source, $dest) {
			return urlencode("${source}_${dest}");
		}

		function build_url($text, $source, $dest) {
			$langpair = $this->create_langpair($source, $dest);
			$text = urlencode($text);
			$action = $this->action;
			$url = $this->action;
			return "$url?lp=$langpair&text=$text";
		}

		function remove_garbage($node) {
			return $node->child[6]->child[0]->child[0]->child[0]->child[2]->child[0]->child[1]->child[4]->child[1]->child[0]->child[0]->child[0];
		}
		
	}
?>
