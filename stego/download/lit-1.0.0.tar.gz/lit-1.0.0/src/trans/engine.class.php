<?php
	# We'll want to add at least one more layer of inheritence here
	# because the engine based on web scrapes will have many
	# similar functions whereas the local engine that we will
	# interact with will have a much different, hopefully more robust
	# backend

	class TranslationEngine {
		var $id = -1;
		var $probability = 100.0;

		function translate($text) {}
	}
	
	class GenericWebEngine extends TranslationEngine {

		var $cache = true;
		var $connection = false;
	
		function get_url($url) {
			$ht = tidy_parse_file("$url");
			if (!$ht) die();
			$ht->cleanRepair();
			return $ht;
		}
		
		function translate($text, $source, $dest) {
			return $this->from_cache($text, $source, $dest);
		}

		function from_cache($text, $source, $target) {		
			if (!$this->cache) return false;
			if ($this->connection == false) {
				echo "Cache not connected, aborting lookup.\n";
				return false;
			}
			$id = $this->id;
			$text = $this->connection->escapeSimple($text);
			$query = "SELECT TARGET FROM TRANS WHERE engine_id=$id ";
			$query .= "AND source_lang='$source' AND target_lang='$target' ";
			$query .= "AND source='$text'";
			$res =& $this->connection->query($query);
			if (PEAR::isError($res))
			    die("from_cache: " . $res->getMessage() . " $query\n");
			$res->fetchInto($row);
			if ($res) {
				if ($res->numRows() < 1) {
					$result = false;
				} else {
					$result = $row['target'];
				}
			}
			$res->free();
			return $result;
		}
		
		function add_cache($source, $target, $source_lang, $target_lang) {
			if (!$this->cache) return false;
			if ($this->connection == false) {
				echo "Cache not connected, aborting add.\n";
				return false;
			}
			if (!isset($source) || !isset($target))
				return;
			$engine_id = $this->id;
			$this->connection->escapeSimple($source);
			$this->connection->escapeSimple($target);
			$id = $this->connection->nextId('TRANS');
			$stmt = $this->connection->prepare("INSERT INTO TRANS
				(id, source_lang, source, target_lang, target, engine_id)
				VALUES (?, ?, ?, ?, ?, ?)");
			$values = array(
				$id,
				$source_lang,
				$source,
				$target_lang,
				$target,
				$engine_id
			);
			$res = $this->connection->execute($stmt, $values);
			if (PEAR::isError($res))
			    die("add_cache: " . $res->getMessage() . "\n >> " . $query);
		}
		
	}
?>
