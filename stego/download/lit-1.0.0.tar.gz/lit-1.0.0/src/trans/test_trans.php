#!/usr/bin/php -q
<?php
	include("./google.class.php");
	include("./babelfish.class.php");
	include("./linguatec.class.php");

	$engine = "Linguatec";

	#if ($argv[1]) $engine = $argv[1];
	$engine .= "Engine";

	#$file = $argv[2];
	if (!isset($file)) $file = "php://stdin";
		
	$e = new $engine;
	$text = file_get_contents($file);
	#$e->from_cache($text, "en", "de");
	$t = $e->translate($text, "de", "en");
	echo "$t\n";
?>
