<pre>
<?php

include "../db_connect.php";

function decanonicalize($orig, $trans) { 
  $ret = $trans;
  $pos = 0;
  while (substr($trans, $pos, 1) == " ")
  	$pos++;
  if (ctype_upper($trans[$pos]) && (! ctype_upper($orig[0])))
    $ret[$pos] = strtolower($ret[$pos]);
  $lasto = $orig[strlen($orig)-1];
  $lastt = $trans[strlen($trans)-1];
  if ( ($lastt == '.') &&
       (in_array($lasto, array(';', ':', '!', '?', ',')) ) ) {
    $ret[strlen($trans)-1] = $lasto;
  }
  return $ret;
}

$query = "SELECT ID, SOURCE, TARGET FROM TRANS WHERE engine_id=130";
$res =& $db->query($query);
if (PEAR::isError($res))
    die("from_cache: " . $res->getMessage() . " $query\n");
$result = array();
while($res->fetchInto($row))
	$result[$row['id']] = array('source' => $row['source'],
								'target' => $row['target']);
$res->free();


$stmt = $db->prepare("UPDATE TRANS SET TARGET = ? WHERE ID = ?;");
foreach ($result as $id=>$values) {
	$k = $values['source'];
	$v = $values['target'];
	$v = decanonicalize($k, $v);
	$values = array($v, $id);
	$res = $db->execute($stmt, $values);
	if (PEAR::isError($res))
    	die("add_cache: " . $res->getMessage() . "\n >> " . $query);
}


?>
</pre>
