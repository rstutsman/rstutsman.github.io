<?php
	$chars = array(
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�",
		"�"
	);


	$codes = array(
		"Ae",
		"Oe",
		"Ue",
		"ss",
		"ae",
		"oe",
		"ue",
		"a",
		"a",
		"a",
		"e",
		"e",
		"e",
		"i",
		"i",
		"u",
		"u",
		"u",
		"c"
	);

	$url_codes = array(
		"%C4",
		"%D6",
		"%DC",
		"%DF",
		"%E4",
		"%F6",
		"%FC",
		"%E0",
		"%E1",
		"%E2",
		"%E8",
		"%E9",
		"%EA",
		"%EE",
		"%EF",
		"%F9",
		"%FA",
		"%FB",
		"%E7"
	);

	function degermanize($s) {
		global $chars, $codes;
		return str_replace($chars, $codes, $s);
	}

	function regermanize($s) {
		global $chars, $url_codes;
		return str_replace($url_codes, $chars, $s);
	}

?>