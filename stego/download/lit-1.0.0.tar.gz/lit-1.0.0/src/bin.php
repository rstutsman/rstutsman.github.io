<?php

	function bin_for_string($s) {
		$r = "";
		for ($i = 0; $i < strlen($s); $i++) {
			$v = base_convert(ord(substr($s, $i, 1)), 10, 2);
			$v = str_pad($v, 8, "0", STR_PAD_LEFT);
			$r .= "$v";
		}
		return $r;
	}

	function get_bit($s, $offset) {
		if ($offset >= strlen($s) * 8) return 0;
		$b = $offset % 8;
		$c = (int)($offset / 8);
		return to_bin(ord(substr($s, $c, 1)) & (1 << $b));
	}

	function set_bit($s, $offset) {
		if ($offset >= strlen($s) * 8) return 0;
		$b = $offset % 8;
		$c = (int)($offset / 8);
		$nc = ord(substr($s, $c, 1));
		$nc |= (1 << $b);
		$s = substr($s, 0, $c - 2) . chr($nc) . substr($s, $c + 1);
		return $s;
	}
	
	function to_bin($v) {
		return ($v > 0) ? 1 : 0;
	}

?>
