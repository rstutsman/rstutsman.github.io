<?php

function wordlist_rcmp(&$l, &$r) {
  if ($l->prob == $r->prob)
	return 0;
  return ($r->prob > $l->prob) ? 1 : -1;
}

function wordlist_cmp(&$l, &$r) {
  if ($l->prob == $r->prob)
	return 0;
  return ($r->prob < $l->prob) ? 1 : -1;
}


function huff_decode($wordlist, &$tree, $debug = false) {
  if (isset($tree['value'])) {
	if ($tree['value']->equals($wordlist)) {
	  if ($debug)
	    echo "//" . $tree['value']->__toString() . "// == //" .
	    		$wordlist->__toString() . "//\n";
	  return "";
	} else {
	  if ($debug) {
	    echo "//" . $tree['value']->__toString() . "// != //" .
	    		$wordlist->__toString() . "//\n";
	    $tree['value']->equals($wordlist, true);
	    debugCompare($tree['value'], $wordlist);
	  }
	  return NULL;
	}
  } else {
	$right = huff_decode($wordlist, $tree['right'], $debug);
	if (isset($right))
	  return "1" . $right;
	$left = huff_decode($wordlist, $tree['left'], $debug);
	if (isset($left))
	  return "0" . $left;
	return NULL;
  }
}

	function huff_encode(&$binary, &$tree) {
		$pos = 0;
		$n = $tree;
		for (;;) {
			if ($pos < strlen($binary)) {
				$b = substr($binary, $pos++, 1);
			} else {
				$fp = fopen("/dev/random", "r");
				if ($fp === false) die("Could not open /dev/random\n");
				$c = fgetc($fp);
				fclose($fp);
				$c = bin_for_string($c);
				$binary .= $c;
				
				echo "WARNING: Binary string exhausted encoding with tree\n";
				echo "\textending with random padding ($c)\n";
				continue;
			}
			if ($b == "1") {
				if (isset($n['right'])) {
					$n = $n['right'];					
					if (!isset($n['left']) && !isset($n['right'])) {
						$s = $n['value'];
						break;
					}
				} else {
					die("Object indicates path in tree that does not exist.");
				}
			} else {
				if (isset($n['left'])) {
					$n = $n['left'];
					if (!isset($n['left']) && !isset($n['right'])) {
						$s = $n['value'];
						break;
					}
				} else {
					die("Object indicates path in tree that does not exist.");
				}
			}
		}
		# Choke up on the binary string now
		$binary = substr($binary, $pos);
		return $s->__toString();
	}

	function huff_to_node($sentence, $weight) {
		$n = array();
		$n['value'] = $sentence;
		$n['weight'] = $weight;
		return $n;
	}

	function &huff_combine_nodes(&$l, &$r) {
		$n = array();
		$n['weight'] = $l['weight'] + $r['weight'];
		$n['left'] = $l;
		$n['right'] = $r;
		return $n;
	}

	function huff_rnodecmp(&$l, &$r) {
		if ($l['weight'] == $r['weight'])
			return 0;
		return ($r['weight'] > $l['weight']) ? 1 : -1;
	}

	function &huff_tree(&$results) {
		$forest = array();
		usort($results, "wordlist_rcmp");
		foreach ($results as $wordlist)
		  $forest[] = huff_to_node($wordlist, $wordlist->prob);

		while (($c = count($forest)) > 1) {
			$n = &huff_combine_nodes(array_pop($forest), array_pop($forest));

			# CG Way
			$temp_tree = array();
			$temp_tree[] = $n;
			$c -= 2;
			$temp_min = $n['weight'];

			while ( ($c > 2) && ($forest[$c - 2]['weight'] <= $temp_min) ) {
			  $n = &huff_combine_nodes(array_pop($forest), array_pop($forest));
			  $temp_tree[] = $n;
			  $c -= 2;
			  if ($n['weight'] < $temp_min)
			    $temp_min = $n['weight'];			  
			}
			$temp = array();
		        $i = 0;
			$j = 0;
			$jc = count($temp_tree);
			usort($temp_tree, "huff_rnodecmp");
			while ( ($i < $c) && ($j < $jc) ) {
			  if ( $forest[$i]['weight'] > $temp_tree[$j]['weight'])
			    $temp[] = $temp_tree[$j++];
			  else
			    $temp[] = $forest[$i++];
			}
			while ($i < $c)
			  $temp[] = $forest[$i++];
			while ($j < $jc) 
			  $temp[] = $temp_tree[$j++];
			$forest = $temp;
		}
		return $forest[0];
	}

?>
