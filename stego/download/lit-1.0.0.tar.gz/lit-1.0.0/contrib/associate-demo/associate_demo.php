<?php
  // script that finds possible word-substitutions
  // by trying to find words that in the dictionary
  // translate in similar ways.
  
include("leotranslate.php");

// Config: how many witnesses do we require?
$witnessThreshold = 2;

// debug...
function parr($arr) {
  foreach($arr as $word) {
    echo $word;
  }
}

/**
 * Find similar words for the $trans word.
 * Note that if $trans is not a translation of
 * $original an empty array will be returned.
 * Otherwise the returned array contains at
 * least $trans.
 */
function associate($original, $trans) {
  global $witnessThreshold;

  $result = array();
  $transArr = translate($original, array());
  // echo "TransArr: "; parr($transArr);
  if (! in_array($trans, $transArr))
    return $result; // nothing found!
  $result[] = $trans;
  // set of witness candiates
  $witnessArr = translate($trans, array());
  //echo "WitnessArr: "; parr($witnessArr);
  foreach($transArr as $candidate) {
    // echo "Processing candiate $candidate\n";
    if ("$candidate" == "$trans") {
      continue; // skip this one
    }
    $orginArr = translate($candidate, array());
    $witnessCount = 0;
    foreach($orginArr as $witness) {
      if (in_array($witness, $witnessArr)) 
	$witnessCount++;
    }
    if ($witnessCount >= $witnessThreshold) {
      $result[] = $candidate;	      
    }
  }
  return array_unique($result);
}

// main (for testing)
if ($argc == 4) {
  $witnessThreshold = $argv[3];
 } else {
  echo "Pass two words as arguments and a witness threshold ($argc)!\n";
  die(); 
 }
$result = associate($argv[1], $argv[2]);


foreach($result as $ii=>$word) {
  echo "$ii: $word\n";
}

?>
