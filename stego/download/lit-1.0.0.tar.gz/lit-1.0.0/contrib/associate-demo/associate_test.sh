#!/bin/sh
# Call with arguments filename, german, english
for n in `seq 0 5`
do 
  echo -e "\nRunning $2->$3 with $n witnesses:" >> $1
  echo "Running $2->$3 with $n witnesses."
  php -f associate_demo.php $2 $3 $n | tee -a $1
done
echo " ";
