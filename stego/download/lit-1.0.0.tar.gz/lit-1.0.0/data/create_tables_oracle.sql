DROP SEQUENCE seq_trans_id;
CREATE SEQUENCE seq_trans_id;

DROP TABLE trans;
CREATE TABLE trans
(
	id NUMBER CONSTRAINT pk_trans PRIMARY KEY,
	engine_id NUMBER,
	source_lang CHAR(2) CONSTRAINT nn_trans_source_lang NOT NULL,
	target_lang CHAR(2) CONSTRAINT nn_trans_target_lang NOT NULL,
	source VARCHAR2(4000),
	target VARCHAR2(4000) CONSTRAINT nn_trans_target NOT NULL
);

DROP SEQUENCE seq_map_id;
CREATE SEQUENCE seq_map_id;

DROP TABLE map;
CREATE TABLE map
(
	id NUMBER CONSTRAINT pk_map PRIMARY KEY,
	prob NUMBER CONSTRAINT nn_map_prob NOT NULL,
	source_lang CHAR(2) CONSTRAINT nn_map_source_lang NOT NULL,
	target_lang char(2) CONSTRAINT nn_map_target_lang NOT NULL,
	source VARCHAR(4000),
	target VARCHAR(4000) CONSTRAINT nn_map_target NOT NULL
);

DROP SEQUENCE seq_witness_id;
CREATE SEQUENCE seq_witness_id;

DROP TABLE witness;
CREATE TABLE witness
(
	id NUMBER CONSTRAINT pk_witness PRIMARY KEY,
	source_lang CHAR(2) CONSTRAINT nn_witness_source_lang NOT NULL,
	target_lang CHAR(2) CONSTRAINT nn_witness_target_lang NOT NULL,
	source VARCHAR2(4000) CONSTRAINT nn_witness_source NOT NULL,
	target VARCHAR2(4000) CONSTRAINT nn_witness_target NOT NULL,
	association VARCHAR2(4000) CONSTRAINT nn_witness_association NOT NULL,
	score NUMBER CONSTRAINT nn_witness_score NOT NULL,
	witnesses NUMBER CONSTRAINT nn_witness_witnesses NOT NULL
);

/*
INSERT INTO trans
(
	id,
	engine_id,
	source_lang,
	target_lang,
	source,
	target
)
VALUES
(
	seq_trans_id.NEXTVAL,
	1,
	'en',
	'de',
	'Hello.',
	'Hallo.'
);
*/
