#!/usr/bin/perl
use strict;
use Switch;

sub gen_insert {
	my $s_lang = shift;
	my $t_lang = shift;
	my $src = shift;
	my @tgt = shift;
	foreach (@tgt) {
		print <<SQL
INSERT INTO MAP
(
	ID,
	SOURCE_LANG,
	TARGET_LANG,
	SOURCE,
	TARGET
) VALUES (
	SEQ_MAP_ID.NEXTVAL,
	'$s_lang',
	'$t_lang',
	'$src',
	'$_'
);

SQL
	}
}

if (!$ARGV[2]) {
	die "\tcleanup_dict.pl <source_lang> <target_lang> <dict_file>\n";
}

my $s_lang = $ARGV[0];
my $t_lang = $ARGV[1];

my $dictfile = $ARGV[2];

open (DICT, "< $dictfile") || die ("can't open dict: $!");

my $word = "";
my $trans;
my @trans_words;
while (<DICT>) {
	SWITCH: {
		/^\S/ && do {
			s/ \[.*$//;
			s/ \(.*\)//;
			chomp;
			$word = $_;
			$trans = "";
		};
		/^\s/ && do {
			s/^\s*//;
			chomp;
			$trans = $_;
			@trans_words = split/;/;
		};
		(/^00/ || /^\s$/) && do {
			$word = "";
			$trans = "";
		};
	}
	if ($word ne "" && $trans ne "") {
		gen_insert $s_lang, $t_lang, $word, @trans_words;
		$word = $trans = "";
	}
}

close (DICT);
